<html>
<head>
<title>Catalogo de estudios</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
function EliReg(){
   if(confirm("ATENCION!\r Desea dar de Baja este registro?")){
	  return(true);	   
   }else{
      document.form1.cKey.value='NUEVO';
   	  return(false);
   }
} 
  
function ValDato(cCampo){//Aqui mando el nombre del campo poro como es 1 campo a validar pues ya lo hago directo
if(cCampo=="Estudio"){document.form1.Estudio.value=document.form1.Estudio.value.toUpperCase();}
if(cCampo=="Descripcion"){document.form1.Descripcion.value=document.form1.Descripcion.value.toUpperCase();}
if(cCampo=="Condiciones"){document.form1.Condiciones.value=document.form1.Condiciones.value.toUpperCase();}
if(cCampo=="Tubocantidad"){document.form1.Tubocantidad.value=document.form1.Tubocantidad.value.toUpperCase();}
if(cCampo=="Equipo"){document.form1.Equipo.value=document.form1.Equipo.value.toUpperCase();}
}
//-->
</script>
</head>
<body>
<div id="Layer1" style="position:absolute; left:10px; top:12px; width:958px; height:88px; z-index:1; background-image:  url(lib/fondo.jpg); layer-background-image:  url(lib/fondo.jpg); border: 1px none #000000;"> 
  <table width="100%" height="89" border="0">
    <tr>
      <td width="16%" height="76"><div align="center"><a href="estudios.php?busca=<?php echo $cKey; ?>"><img src="lib/logo2.jpg" alt="Regresar" width="100" height="80" border="0"></a></div></td>
      <td width="70%"><p>&nbsp;</p>
        <p align="center"><img src="lib/estudios.jpg" alt="Catalogo de colores" width="150" height="25"></p></td>
      <td width="14%">&nbsp;</td>
    </tr>
  </table>    
</div>
<div id="Layer2" style="position:absolute; left:11px; top:111px; width:958px; height:388px; z-index:2"> 
  <table width="100%" height="391" border="0">
    <tr> 
      <td width="12%" height="387"><div align="center"></div></td>
      <td width="3%">&nbsp;</td>
      <td width="85%">
	      <form name="form1" method="get" action="movest.php">
		    <?php
		    include("lib/kaplib.php");
	        $link=conectarse();
	        $tabla="est";
   	        $cReg=mysql_query("select estudio,descripcion,objetivo,condiciones,tubocantidad,tiempoest,entord,entexp,enthos,enturg,equipo,muestras,estpropio from $tabla where (estudio= '$cKey')",$link);
	        $cCpo=mysql_fetch_array($cReg);
	        $lAg=$cKey=='NUEVO';
			?>
		    <font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#003399">
		    <p>Estudio...........:<input type="text" name="Estudio" value ='<?php if(!$lAg){echo $cCpo[0];} ?>' maxlength="7" onBlur="ValDato('Estudio')" size="6"></p>
			<p>Descripcion......:<input type="text" name="Descripcion" value ='<?php if(!$lAg){echo $cCpo[1];} ?>' maxlength="40" onBlur="ValDato('Descripcion')" size="50"></p>		
          <p>Objetivo..........: 
            <TEXTAREA NAME="Objetivo" COLUMNS="4" ROWS="6" >
			 Texto:<?php echo "$cCpo[2]"; ?>
            </TEXTAREA>
          </p>
          <p>Condiciones......: 
            <TEXTAREA NAME="Condiciones" COLUMNS="80" ROWS="6" >
			<?php echo "$cCpo[3]";?>
            </TEXTAREA>
          </p>
			<p>Tubo y cnt.de muestra a tomar......: <input name=Tubocantidad type=text size=30 value='<?php echo $cCpo[4];?>' onBlur="ValDato('Tubocantidad')"></p>
			<p>Equipo a Usar : <input name="Equipo" type="text" size="20" value='<?php echo $cCpo[10];?>' onBlur="ValDato('Equipo')"></p>
          <p>Tiempo real del estudio:<input name="Tiempoest" type="text" size="5" value='<?php echo $cCpo[5];?>'>
		  Numero de Muestras: <input name=" Muestras" type="text" size="5" value='<?php echo $cCpo[11];?>'>
		  Estudio propio[S/N]:
		  <select name=Estpropio>
		  <option value=S>S</option>
	      <option value=N>N</option>
		  <option selected><?php echo $cCpo[12]; ?></option>
          </select></p></font>
          <p><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#003399">Dias de Entrega Ordinaria: 
			<?php 
			$nCt=0;
			echo "<select name=Entord>";
			while ($nCt<=30){
			  echo "<option value=$nCt>$nCt</option>";	
			  $nCt++;			
			}
            echo "<option selected>$cCpo[6]</option>";
            echo "</select>";
            echo "Express:"; 
			$nCt=0;
            echo "<select name=Entexp>";
			while ($nCt<=30){
			  echo "<option value=$nCt>$nCt</option>";	
			  $nCt++;	
			}
			echo "<option selected>$cCpo[7]</option>";
            echo "</select>";
            echo "Hospital: ";
			$nCt=0;
            echo "<select name=Enthos>";
			while ($nCt<=30){
			  echo "<option value=$nCt>$nCt</option>";	
			  $nCt++;			
			}
            echo "<option selected>$cCpo[8]</option>";
            echo "</select>";
            echo "Urgencias: ";
			$nCt=0;
            echo "<select name=Enturg>";
			while ($nCt<=30){
			   echo "<option value=$nCt>$nCt</option>";				
			  $nCt++;	
			}
            echo "<option selected>$cCpo[9]</option>";
            echo "</select>";
			?>
            </font></p>
            <p><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#003399">
            <input type="hidden" name="busca" value=<?php echo $busca; ?>>
            <input type="hidden" name="cKey" value=<?php echo $cKey; ?>>
            <input type="IMAGE" name="Guarda" src="lib/guardar.jpg" alt="Guarda los ultimos movimientos y salte" width="150" height="25" >
            <input type="IMAGE" name="Elimina" src="lib/eliminar.jpg" alt="Elimina este registro" onClick="EliReg()" width="150" height="25">
            </font> </p>
        </form>
		<p>&nbsp;<a href="estudios.php?busca=-1"><img src="lib/cancelar.jpg" width="150" height="25" border="0"></a></p>
        <p>&nbsp;</p></td>
    </tr>
  </table>
</div>
</body>
</html>
