<HTML>
<HEAD>
	<TITLE>Sistema Administrativo...kap</TITLE>
</HEAD>
<div align="center"><B><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2">M 
  e n s a je</font></B> </div>
<P align="center"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
  <?php echo  $Msj ;?>
  <BR>
  </font>
<CENTER>
  <form name="form3" method="post" action=<?php echo $url; ?>>
    <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
    <?php $url; ?>
    <input type="submit" name="Submit" value="Presione aqui para continuar">
    </font> 
  </FORM>
</CENTER></BODY>
</HTML>
