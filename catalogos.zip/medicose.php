<html>
<head>
<title>Laboratorio Duran</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function ValGeneral(){
var lRt;
lRt=true;
if(document.form1.Apellidom.value==""){lRt=false;}
if(document.form1.Apellidop.value==""){lRt=false;}
if(document.form1.Nombre.value==""){lRt=false;}
if(!lRt){
	alert("Faltan datos por llenar, favor de verificar");
    return false;
}
    return true;
}

function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

function EliReg(){
   if(confirm("ATENCION!\r Desea dar de Baja este registro?")){
	  return(true);	   
   }else{
      document.form1.cKey.value='NUEVO';
   	  return(false);
   }
} 
 
function ValDato(cCampo){
if (cCampo=='Rfc'){document.form1.Rfc.value=document.form1.Rfc.value.toUpperCase();
}if (cCampo=='Cedula'){document.form1.Cedula.value=document.form1.Cedula.value.toUpperCase();
}if (cCampo=='Apellidop'){document.form1.Apellidop.value=document.form1.Apellidop.value.toUpperCase();
}if (cCampo=='Apellidom'){document.form1.Apellidom.value=document.form1.Apellidom.value.toUpperCase();
}if (cCampo=='Nombre'){document.form1.Nombre.value=document.form1.Nombre.value.toUpperCase();
}if (cCampo=='Tipo'){document.form1.Dirparticular.value=document.form1.Dirparticular.value.toUpperCase();
}if (cCampo=='Locparticular'){document.form1.Locparticular.value=document.form1.Locparticular.value.toUpperCase();   
}if (cCampo=='Dirparticular'){document.form1.Dirparticular.value=document.form1.Dirparticular.value.toUpperCase();   
}if (cCampo=='Locconsultorio'){document.form1.Locconsultorio.value=document.form1.Locconsultorio.value.toUpperCase();   
}if (cCampo=='Dirconsultorio'){document.form1.Dirconsultorio.value=document.form1.Dirconsultorio.value.toUpperCase();   
}if (cCampo=='Codigo'){document.form1.Codigo.value=document.form1.Codigo.value.toUpperCase();   
}if (cCampo=='Especialidad'){document.form1.Especialidad.value=document.form1.Especialidad.value.toUpperCase();
}if (cCampo=='Subespecialidad'){document.form1.Subespecialidad.value=document.form1.Subespecialidad.value.toUpperCase();
}if (cCampo=='Telconsultorio'){document.form1.Telconsultorio.value=document.form1.Telconsultorio.value.toUpperCase();
}if (cCampo=='Telcelular'){document.form1.Telcelular.value=document.form1.Telcelular.value.toUpperCase();
}if (cCampo=='Diasconsulta'){document.form1.Diasconsulta.value=document.form1.Diasconsulta.value.toUpperCase();
}if (cCampo=='Hravisita'){document.form1.Hravisita.value=document.form1.Hravisita.value.toUpperCase();
}if (cCampo=='Hraconsulta'){document.form1.Hraconsulta.value=document.form1.Hraconsulta.value.toUpperCase();}
}
//-->
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">

<table width="887" border="0" cellpadding="0" cellspacing="0" mm:layoutgroup="true" height="667">
  <tr> 
    <td width="1162" height="667" valign="top"> 
      <table width="100%" border="0" height="88" background="lib/fondo1.jpg">
        <tr>
          <td width="13%" height="72"> 
            <div align="center"><a href="medicos.php"><img src="lib/logo2.jpg" width="100" height="80" border="0"></a></div>
          </td>
          <td width="53%" height="72"> 
            <div align="center"><img src="lib/medicos.jpg" width="150" height="25"></div>
          </td>
          <td width="34%" height="72">&nbsp;</td>
        </tr>
      </table>
      <table width="100%" border="0" height="482">
        <tr>
          <td width="15%" height="478"> 
            <div align="center">
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p><a href="medicos.php"><img src="lib/SmallExit.BMP" alt="Regresar" border="0"></a></p>
            </div>
          </td>
		  <form name="form1" method="get" action="movmed.php" onSubmit="return ValGeneral();" >
		    <?php
            include("lib/kaplib.php");
	        $link=conectarse();
	        $tabla="med";
   	        $cReg=mysql_query("select medico,apellidop,apellidom,nombre,rfc,cedula,codigo,nombrec,especialidad,subespecialidad,dirparticular,locparticular,telparticular,dirconsultorio,locconsultorio,telconsultorio,telcelular,mail,diasconsulta,hravisita,hraconsulta,zona,institucion from $tabla where (medico= '$cKey')",$link);
	        $cCpo=mysql_fetch_array($cReg);
	        $lAg=$cKey=='NUEVO';
	        $Fecha=date("Y-m-d");
	        ?>
            <td width="85%" height="478"><font color="#0000FF"><b>Medico:</b></font> 
              <font color="#0000FF"> 
              <input name="Medico" type="text" size="5" value ='<?php if(!$lAg){echo $cCpo[0];}else{echo "Nuevo";}?>'>
            </font> 
            <p> <font size="2" color="#0000FF">Apellido paterno 
                <input name="Apellidop" type="text" size="15" value ='<?php if(!$lAg){echo $cCpo[1];} ?>'  onBlur="ValDato('Apellidop')">
                Apellido materno 
                <input name="Apellidom" type="text" size="15" value ='<?php if(!$lAg){echo $cCpo[2];} ?>'  onBlur="ValDato('Apellidom')">
                Nombre 
                <input name="Nombre" type="text" size="15" value ='<?php if(!$lAg){echo $cCpo[3];} ?>'  onBlur="ValDato('Nombre')">
                </font></p>
              <p>Rfc 
              <input type="text" name="Rfc" value ='<?php if(!$lAg){echo $cCpo[4];} ?>' onBlur="ValDato('Rfc')">
              Cedula 
              <input type="text" name="Cedula" value ='<?php if(!$lAg){echo $cCpo[5];} ?>' onBlur="ValDato('Cedula')">
              Codigo postal 
              <input type="text" name="Codigo" value ='<?php if(!$lAg){echo $cCpo[6];} ?>'onBlur="ValDato('Codigo')">
              </p>
            <p>Especialidad 
              <input type="text" name="Especialidad" value ='<?php if(!$lAg){echo $cCpo[8];} ?>'onBlur="ValDato('Especialidad')">
              Sub-especialidad 
              <input type="text" name="Subespecialidad" value ='<?php if(!$lAg){echo $cCpo[9];} ?>' onBlur="ValDato('Subespecialidad')">
              </p>
            <p>Direccion part. 
              <input type="text" name="Dirparticular" value ='<?php if(!$lAg){echo $cCpo[10];} ?>' onBlur="ValDato('Dirparticular')">
              Localidad 
              <input type="text" name="Locparticular" value ='<?php if(!$lAg){echo $cCpo[11];} ?>' onBlur="ValDato('Locparticular')">
              Tel. 
              <input type="text" name="Telparticular" value ='<?php if(!$lAg){echo $cCpo[12];} ?>' onBlur="ValDato('Telparticular')" >
              </p>
            <p>Direccion cons 
              <input type="text" name="Dirconsultorio" value ='<?php if(!$lAg){echo $cCpo[13];} ?>' onBlur="ValDato('Dirconsultorio')">
              Localidad 
              <input type="text" name="Locconsultorio" value ='<?php if(!$lAg){echo $cCpo[14];} ?>' onBlur="ValDato('Locconsultorio')">
              Tel. 
              <input type="text" name="Telconsultorio" value ='<?php if(!$lAg){echo $cCpo[15];} ?>' onBlur="ValDato('Telconsultorio')">
              </p>
            <p>Tel.celular 
              <input type="text" name="Telcelular" value ='<?php if(!$lAg){echo $cCpo[16];} ?>' onBlur="ValDato('Telcelular')">
              Mail 
              <input type="text" name="Mail" size="35" value ='<?php if(!$lAg){echo $cCpo[17];} ?>'>
              </p>
            <p>Dias consulta 
              <input type="text" name="Diasconsulta" size="25" value ='<?php if(!$lAg){echo $cCpo[18];} ?>' onBlur="ValDato('Diasconsulta')" >
              Hra.visitas 
              <input type="text" name="Hravisita" size="25" value ='<?php if(!$lAg){echo $cCpo[19];} ?>' onBlur="ValDato('Hravisita')">
              Hra.consulta 
              <input type="text" name="Hraconsulta" size="5" value ='<?php if(!$lAg){echo $cCpo[20];} ?>' onBlur="ValDato('Hraconsulta')">
              </p>
			  <?php
 		       echo "Zona: ";
		       echo "<select name='Zona'>";
		       $cDes=mysql_query("select zona,descripcion from zns",$link);
			   $lBd=false;
			   while ($cDesc=mysql_fetch_array($cDes)){
                   echo "<option value=$cDesc[0]>$cDesc[0]:&nbsp$cDesc[1]</option>"; 
				   if($cCpo[21]==$cDesc[0]){
				     $lBd=true;
				     echo "<option selected value=$cCpo[21]>$cDesc[0]&nbsp;$cDesc[1]</option>";
				   }
               } 
			   if(!$lBd){echo "<option selected value=$cCpo[21]>$cDesc[0]&nbsp;$cDesc[1]</option>";}
	  	       echo "</select>";
			   echo "Institucion: ";
		       echo "<select name='Institucion'>";
		       $cDes=mysql_query("select institucion,descripcion from inst",$link);
			   $lBd=false;
			   while ($cDesc=mysql_fetch_array($cDes)){
                   echo "<option value=$cDesc[0]>$cDesc[0]:&nbsp$cDesc[1]</option>"; 
				   if($cCpo[22]==$cDesc[0]){
				     $lBd=true;
				     echo "<option selected value=$cCpo[22]>$cDesc[0]&nbsp;$cDesc[1]</option>";
				   }
               } 
			   if(!$lBd){echo "<option selected value=$cCpo[22]>$cDesc[0]&nbsp;$cDesc[1]</option>";}
	  	       echo "</select>";
			   ?>	
              </p>
            <p>
              <input type="hidden" name="busca" value=<?php echo $busca; ?>>
              <input type="hidden" name="cKey" value=<?php echo $cKey; ?>>
              <input type="IMAGE" name="Guarda" src="lib/guardar.jpg" alt="Guarda los ultimos movimientos y salte" width="150" height="25" >
              &nbsp;&nbsp; 
              <input type="IMAGE" name="Elimina" src="lib/eliminar.jpg" alt="Elimina este registro" onClick="EliReg()" width="150" height="25">
            </p>
            <p>&nbsp; </p>
          </td>
		  </form>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
