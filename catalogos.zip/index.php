<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Laboratorio Clinico Duran</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body>

<div id="Layer1" style="position:absolute; left:10px; top:12px; width:1077px; height:958px; z-index:1; background-image:  url(lib/fondo.jpg); layer-background-image:  url(lib\fondo.jpg); border: 1px none #000000;"> 
  <table width="100%" height="80" border="0">
    <tr>
      <td width="13%" height="76"><div align="center"><img src="lib/logo2.jpg" width="100" height="80"></div></td>
      <td width="73%">
        <p align="left"><img src="lib/medics.bmp"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="lib/estudis.BMP"></p>
        <p align="center"><a href="catalogos.php"><img src="lib/catalogos.jpg" width="150" height="25" border="0"></a>&nbsp;<img src="lib/recepcion.jpg" width="150" height="25">&nbsp;<img src="lib/preanaliticos.jpg" width="150" height="25">&nbsp;<img src="lib/analisis.jpg" width="150" height="25"></p></td>
      <td width="14%">&nbsp;</td>
    </tr>
  </table>  
  <table width="100%" height="781" border="0">
    <tr> 
      <td width="13%" height="777">
        <p align="center"><img src="lib/signos.BMP"></p>
        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td width="73%" background="lib/fondo2.jpg"><div align="center">
          <p><img src="lib/logo1.jpg" width="400" height="200"></p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div></td>
      <td width="14%">&nbsp;</td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <div align="right"></div>
  <div align="center"></div>
  <p>&nbsp;</p>
</div>
</body>
</html>
