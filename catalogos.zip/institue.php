<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Catalogo de Instituciones</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
function EliReg(){
   if(confirm("ATENCION!\r Desea dar de Baja este registro?")){
	  return(true);	   
   }else{
      document.form1.cKey.value='NUEVO';
   	  return(false);
   }
} 
  
function ValGeneral(){
var lRt;
lRt=true;
if(document.form1.Nombre.value==""){lRt=false;}
if(document.form1.Lista.value==""){lRt=false;}
if(!lRt){
	alert("Faltan datos por llenar, favor de verificar");
    return false;
}
    return true;
}
function ValDato(cCampo){//Aqui mando el nombre del campo poro como es 1 campo a validar pues ya lo hago directo
if(cCampo=="Nombre"){document.form1.Nombre.value=document.form1.Nombre.value.toUpperCase();}
if(cCampo=="Alias"){document.form1.Alias.value=document.form1.Alias.value.toUpperCase();}
if(cCampo=="Direccion"){document.form1.Direccion.value=document.form1.Direccion.value.toUpperCase();}
if(cCampo=="Localidad"){document.form1.Localidad.value=document.form1.Localidad.value.toUpperCase();}
if(cCampo=="Municipio"){document.form1.Municipio.value=document.form1.Municipio.value.toUpperCase();}
if(cCampo=="Referencia"){document.form1.Referencia.value=document.form1.Referencia.value.toUpperCase();}
if(cCampo=="Codigo"){document.form1.Codigo.value=document.form1.Codigo.value.toUpperCase();}
if(cCampo=="Rfc"){document.form1.Rfc.value=document.form1.Rfc.value.toUpperCase();}
if(cCampo=="Fax"){document.form1.Fax.value=document.form1.Fax.value.toUpperCase();}
if(cCampo=="Telefono"){document.form1.Telefono.value=document.form1.Telefono.value.toUpperCase();}
if(cCampo=="Director"){document.form1.Director.value=document.form1.Director.value.toUpperCase();}
if(cCampo=="Subdirector"){document.form1.Subdirector.value=document.form1.Subdirector.value.toUpperCase();}
}
//-->
</script>
</head>
<body>
<div id="Layer1" style="position:absolute; left:10px; top:12px; width:958px; height:88px; z-index:1; background-image:  url(lib/fondo.jpg); layer-background-image:  url(lib/fondo.jpg); border: 1px none #000000;"> 
  <table width="100%" height="89" border="0">
    <tr>
      <td width="16%" height="76"><div align="center"><a href="institu.php?busca=<?php echo $cKey; ?>"><img src="lib/logo2.jpg" alt="Regresar" width="100" height="80" border="0"></a></div></td>
      <td width="70%"><p>&nbsp;</p>
        <p align="center"><img src="lib/instituciones.jpg" alt="Catalogo de colores" width="150" height="25"></p></td>
      <td width="14%">&nbsp;</td>
    </tr>
  </table>    
</div>
<div id="Layer2" style="position:absolute; left:11px; top:99px; width:958px; height:303px; z-index:2"> 
  <table width="100%" height="353" border="0">
    <tr> 
      <td width="16%" height="155"><div align="center"></div></td>
      <td width="2%">&nbsp;</td>
      <td width="82%">
	    <form name="form1" method="get" action="movins.php" onSubmit="return ValGeneral();" >
		  <?php
            include("lib/kaplib.php");
	        $link=conectarse();
	        $tabla="inst";
   	        $cReg=mysql_query("select institucion,nombre,alias,direccion,localidad,municipio,referencia,codigo,rfc,fax,telefono,director,subdirector,lista from $tabla where (institucion= '$cKey')",$link);
	        $cCpo=mysql_fetch_array($cReg);
	        $lAg=$cKey=='NUEVO';
		    echo "<strong><font color=006699 face=Verdana, Arial, Helvetica, sans-serif size=2>Institucion : $cKey";
		    echo "<p>Nombre..........:";
			echo "<input name=Nombre type=text size=45 value='$cCpo[1]' onBlur=ValDato('Nombre')>";
			echo "Alias :";
			echo "<input name=Alias type=text size=10 value='$cCpo[2]' onBlur=ValDato('Alias')></p>";
			echo "<p>Direccion.......:";
			echo "<input name=Direccion type=text size=35 value='$cCpo[3]' onBlur=ValDato('Direccion')></p>";
			echo "<p>Localidad.......:";
			echo "<input name=Localidad type=text size=30 value='$cCpo[4]' onBlur=ValDato('Localidad')>";
			echo "&nbsp;&nbsp;&nbsp;Municipio :";
			echo "<input name=Municipio type=text size=30 value='$cCpo[5]' onBlur=ValDato('Municipio')></p>";
			echo "<p>Referencia del lugar:";
			echo "<input name=Referencia type=text size=50 value='$cCpo[6]' onBlur=ValDato('Referencia')></p>";			
			echo "<p>Codigo Postal.:";
			echo "<input name=Codigo type=text size=10 value='$cCpo[7]' onBlur=ValDato('Codigo')>";			
	   	    echo "&nbsp;&nbsp;&nbsp;R.f.c:";
  			echo "<input name=Rfc type=text size=10 value='$cCpo[8]' onBlur=ValDato('Rfc')></p>";			
		    echo "<p>Telefono..........:";
			echo "<input name=Telefono type=text size=20 value='$cCpo[10]' onBlur=ValDato('Telefono')>";			
			echo "&nbsp;&nbsp;&nbsp;Fax :";
			echo "<input name=Fax type=text size=20 value='$cCpo[9]' onBlur=ValDato('Fax')>";			
			echo "&nbsp;&nbsp;&nbsp;Lista de precios.:";
		    echo "<select name='Lista'>";
            echo "<option value=1>1</option>"; 
			echo "<option value=2>2</option>"; 
			echo "<option value=3>3</option>"; 
			echo "<option value=4>4</option>"; 
			echo "<option value=5>5</option>"; 
     		echo "<option value=6>6</option>";
			echo "<option value=7>7</option>";	
			echo "<option value=8>8</option>";
			echo "<option value=9>9</option>";
			echo "<option value=10>10</option>";
			echo "<option selected value=$cCpo[13]>$cCpo[13]</option>";
			echo "</select></p>";
			echo "<p>Director..........:";
			echo "<input name=Director type=text size=30 value='$cCpo[11]' onBlur=ValDato('document.form1.Director.value')>";			
		    echo "&nbsp;&nbsp;&nbsp;Sub-director :";
			echo "<input name=Subdirector type=text size=30 value='$cCpo[12]' onBlur=ValDato('document.form1.Subdirector.value')></p></font></strong>";			
			?>	
          <p>
            <input type="hidden" name="busca" value=<?php echo $busca; ?>>
            <input type="hidden" name="cKey" value=<?php echo $cKey; ?>>
            <input type="IMAGE" name="Guarda" src="lib/guardar.jpg" alt="Guarda los ultimos movimientos y salte" width="150" height="25" >
            &nbsp;&nbsp; &nbsp;&nbsp; 
            <input type="IMAGE" name="Elimina" src="lib/eliminar.jpg" alt="Elimina este registro" onClick="EliReg()" width="150" height="25">
          </p>
        </form>
		<p>&nbsp;<a href="institu.php?busca=-1"><img src="lib/cancelar.jpg" width="150" height="25" border="0"></a></p>
        <p>&nbsp;</p></td>
    </tr>
  </table>
</div>
<div id="Layer4" style="position:absolute; left:13px; top:452px; width:960px; height:54px; z-index:4;"> 
  <table width="100%" height="42" border="0">
    <tr> 
      <td width="16%" height="38"> 
        <div align="center"><a href="institu.php?busca=<?php echo $cKey; ?>"><img src="lib/SmallExit.BMP" alt="Salir" border="0"></a> 
        </div></td>
      <td width="84%">
        <p>&nbsp;</p></td>		
    </tr>
  </table>
</div>
</body>
</html>
