<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body>

<div id="Layer1" style="position:absolute; left:10px; top:12px; width:958px; height:846px; z-index:1; background-image:  url(lib/fondo.jpg); layer-background-image:  url(lib/fondo.jpg); border: 1px none #000000;"> 
  <table width="100%" height="80" border="0">
    <tr>
      <td width="16%" height="76"> 
        <div align="center"><a href="menu.php"><img src="lib/logo2.jpg" width="100" height="80" border="0"></a></div></td>
      <td width="70%">
<p align="center">&nbsp;</p>
        <p align="center"><img src="lib/catalogos.jpg" alt="Catalogo de colores" width="150" height="25">&nbsp;&nbsp;<img src="lib/analisis.jpg" width="150" height="25">&nbsp;&nbsp;<img src="lib/preanaliticos.jpg" width="150" height="25">&nbsp;&nbsp;<img src="lib/analisis.jpg" width="150" height="25"></p></td>
      <td width="14%">&nbsp;</td>
    </tr>
  </table>  
  <table width="100%" height="697" border="0">
    <tr>
      <td width="13%" height="693">
<p><img src="lib/pacientes.jpg" width="150" height="25"></p>
        <p><a href="medicos.php"><img src="lib/medicos.jpg" width="150" height="25" border="0"></a></p>
        <p><a href="estudios.php?busca=-1"><img src="lib/estudios.jpg" width="150" height="25" border="0"></a></p>
        <p><a href="zonas.php"><img src="lib/zonas.jpg" width="150" height="25" border="0"></a></p>
        <p><a href="institu.php?busca=-1"><img src="lib/instituciones.jpg" width="150" height="25" border="0"></a></p>
        <p><a href="lista.php"><img src="lib/precios.jpg" width="150" height="25" border="0"></a></p>
        <p>&nbsp;</p>
        <p align="center"><a href="menu.php"><img src="lib/SmallExit.BMP" border="0"></a></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p></td>
      <td width="73%" background="lib/fondo2.jpg"><div align="center">
          <p><img src="lib/logo1.jpg" width="400" height="200"></p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        </div></td>
      <td width="14%">&nbsp;</td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <div align="right"></div>
  <div align="center"></div>
  <p>&nbsp;</p>
</div>
</body>
</html>
